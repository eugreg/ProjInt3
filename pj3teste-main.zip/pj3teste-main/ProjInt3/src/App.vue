<script setup>
import HeaderComp from "@/components/HeaderComp.vue";
</script>

<template>
  <RouterView />
</template>

<style></style>
