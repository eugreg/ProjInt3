<script>
export default {};
</script>
<template>
    <div class="Flex">
  <div class="imgcorra2">
    <router-link to=""><img class="CardImg" src="@/assets/img/panteranegra.jpg" alt=""></router-link>
  </div>
    <div class="Cards"></div>  
    <div class="Cards"></div>
    <div class="Cards"></div>
    <div class="Cards"></div>
    </div>      
</template>