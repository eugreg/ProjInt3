<script>
export default {};
</script>
<template>
  <div class="cardfilmes">
    <h4>filmes</h4>
  </div>
</template>
