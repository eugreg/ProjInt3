<script>
export default {};
</script>
<template>
  <div class="imagem">
    <div class="django">
      <h2 class="imagem-h2">
        3 formas para descobrir rapidamente o filme ou a série ideal para você.
      </h2>
    </div>
  </div>
</template>
