<script>
export default {};
</script>
<template>
    <div class="Flex">
  <div class="imgcorra2">
    <router-link to="AtorView"><img class="CardImg" src="@/assets/img/daniel.jpg" alt=""></router-link>
  </div>
    <div class="Cards"></div>  
    <div class="Cards"></div>
    <div class="Cards"></div>
    <div class="Cards"></div>
    </div>


  

        
</template>