<script>
export default {};
</script>
<template>
<div class="Flex">
  <div class="imgcorra2">
    <router-link to="corra"><img class="CardImg" src="@/assets/img/corra.jpg" alt=""></router-link>
  </div>
    <div class="Cards"></div>  
    <div class="Cards"></div>
    <div class="Cards"></div>
    <div class="Cards"></div>
    </div> 
</template>

