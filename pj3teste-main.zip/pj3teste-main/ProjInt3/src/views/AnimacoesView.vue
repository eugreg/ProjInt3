<script setup>
import HeaderComp from '@/components/HeaderComp.vue';
</script>
<template>
    <nav>
    <HeaderComp/>
    </nav>
    <main>
        <div class="titulo">
            <h1>Animações</h1>
        </div>
    </main>
</template>